<footer class="blog-footer">
  <p>Blog template built for <a href="https://www.itisrossi.edu.it/">ITIS Rossi Vicenza</a></p>
  <p>
    <a href="#">Back to top</a>
  </p>
</footer><?php /**PATH C:\xampp\htdocs\blog-app\resources\views/partials/footer.blade.php ENDPATH**/ ?>
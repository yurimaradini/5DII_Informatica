<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\News;
use Illuminate\Http\Request;
use Illuminate\View\View;

class NewsController extends Controller
{
    public function index(): View
    {
    	$categories = Category::all();

    	$mainNews = News::orderBy('created_at', 'desc')->limit(1)->get()->first();

    	$news = News::orderBy('created_at', 'desc')->limit(10)->offset(1)->get();

        return view('news', [
        	'mainNews' => $mainNews,
            'news' => $news,
            'categories' => $categories
        ]);
    }

    public function getNews($id)
    {
    	$categories = Category::all();

    	$news = News::find($id);

    	return view('news-detail', [
            'news' => $news,
            'categories' => $categories
    	]);
    }

    public function getCategories($id)
    {
        //categorei disponibili per mostrarle nel menu
        $categories = Category::all();

        //categoria da cercare
    	$category = Category::find($id);
        
        //metodo del model Category che ritorna le news di quella categoria
    	$news = $category->news;

    	return view('news', [
            'news' => $news,
            'categories' => $categories
        ]);
    }
}

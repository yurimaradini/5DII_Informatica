function Login(){
    window.location = "login.php";
}

for (let f of document.querySelectorAll(".contenitore2")) {
    f.addEventListener("click", (e) =>{
    
        document.films.film.value = e.target.parentElement.getAttribute('value');
        document.films.submit();
    
    })    
}

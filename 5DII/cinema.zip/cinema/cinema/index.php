<?php
session_start();
if(!isset($_SESSION["lgn"]) || $_SESSION["lgn"] == "Login"){
    $_SESSION["lgn"] = "Login";
}
else{
    
}

$_SESSION["name"] = "";
if(!isset($_POST["gigi"])){
$_POST["gigi"] = 1;
$dbh = new PDO("mysql:host=localhost", "root", "");

$dbh->exec("CREATE DATABASE IF NOT EXISTS 5dii_cinema;
    CREATE USER IF NOT EXISTS 'root'@'localhost' IDENTIFIED BY '';
    GRANT ALL ON 5dii_cinema.* TO 'root'@'localhost';
    FLUSH PRIVILEGES;
    ");

require_once "dbconfig.php";

$dbh->exec("CREATE TABLE IF NOT EXISTS users (
    ID int not null AUTO_INCREMENT, 
    name varchar(20) not null, 
    email varchar(80) not null, 
    password varchar(80) not null,
    unique(email),
    primary key(ID)
    );

CREATE TABLE IF NOT EXISTS films (
    ID int not null AUTO_INCREMENT, 
    title varchar(100) not null, 
    plot varchar(1000), 
    thumbnail varchar(200) not null,
    primary key(ID),
    unique(title)
    );

CREATE TABLE IF NOT EXISTS projections (
    ID int not null AUTO_INCREMENT, 
    ID_film int not null, 
    day date not null, 
    time time not null,
    room int not null,
    primary key(ID),
    FOREIGN KEY(ID_film) REFERENCES films(ID),
    unique(day,time,room)
    );

CREATE TABLE IF NOT EXISTS bookings (
    code int not null AUTO_INCREMENT, 
    ID_projection int not null, 
    ID_user int not null, 
    sit_number int not null,
    primary key(code),
    FOREIGN KEY(ID_projection) REFERENCES projections(ID),
    FOREIGN KEY(ID_user) REFERENCES users(ID),
    unique(ID_user,ID_projection,sit_number)
  );

CREATE TABLE IF NOT EXISTS payments (
    booking_code int not null, 
    ID_user int not null, 
    amount int not null,
    primary key(booking_code),
    FOREIGN KEY(booking_code) REFERENCES bookings(code),
    FOREIGN KEY(ID_user) REFERENCES users(ID)
  );

INSERT IGNORE INTO `films` (`title`, `plot`, `thumbnail`) VALUES
( 'Joker', 'Arthur Fleck, attore comico fallito ed ignorato dalla società, vaga per le strade di Gotham City iniziando una lenta e progressiva discesa negli abissi della follia, sino a divenire una delle peggiori menti criminali della storia.', 'https://mir-s3-cdn-cf.behance.net/project_modules/disp/eca6ff97682649.5ecb374c7908d.jpg'),
( 'The Batman\n', 'Quando l\'Enigmista, un sadico assassino seriale, inizia a uccidere le principali figure politiche di Gotham, Batman è costretto a indagare sulla corruzione in città e a mettere in discussione il coinvolgimento della sua famiglia.', 'https://m.media-amazon.com/images/M/MV5BOGE2NWUwMDItMjA4Yi00N2Y3LWJjMzEtMDJjZTMzZTdlZGE5XkEyXkFqcGdeQXVyODk4OTc3MTY@._V1_.jpg'),
( 'Top Gun: Maverick', 'Dopo più di trent\'anni di servizio come uno dei migliori aviatori della Marina, Pete Mitchell è al suo posto, spingendosi al limite come coraggioso pilota collaudatore che affronta nuove sfide.', 'https://pad.mymovies.it/filmclub/2012/03/009/locandinapg1.jpg'),
( 'Avatar 2', 'Jake vive felicemente la sua vita insieme a Neytiri ma Pandora nasconde ancora numerosi misteri. In veste di patriarca si ritroverà a dover combattere una dura guerra contro gli umani.', 'https://static2.amica.it/wp-content/uploads/2022/09/ITALIA_Teaser_FIN05_Avatar2441.jpg?v=1206031'),
( 'Il gatto con gli stivali 2 ', 'Per la prima volta dopo dieci anni, DreamWorks Animation presenta un nuovo capitolo dalle favole di Shrek in cui l\'audace fuorilegge, il Gatto con gli Stivali, pagherà un prezzo alto per la sua famigerata passione per il pericolo e la noncuranza per la sicurezza. Nonostante abbia perso il conto lungo la strada, il Gatto ha bruciato otto delle sue nove vite. Per riaverle si imbarcherà in un\'impresa colossale. Nella versione originale, il candidato all\'Oscar Antonio Banderas torna a dar voce al famoso Gatto accompagnandolo in un viaggio epico alla ricerca della leggendaria Stella dei Desideri nella Foresta Nera per riappropriarsi delle vite perdute. Avendo una sola vita a disposizione, il Gatto sarà costretto a chiedere aiuto alla sua ex partner e nemesi: l\'affascinante Kitty \"Zampe di Velluto\" (la candidata all\'Oscar Salma Hayek). Nella loro impresa, il Gatto e Kitty saranno aiutati - contro ogni buon senso - da un malconcio, loquace e gioioso randagio, di nome Perro (Harvey Guillén, \"Vita da vampiro - What We Do in the Shadows\"). Insieme, il nostro trio di eroi dovrà rimanere un passo avanti rispetto a Riccioli D\'oro (il candidato all\'Oscar Florence Pugh, \"Black Widow\") e alla Famiglia Criminale dei tre Orsi, composta da \"Big\" Jack Horner (il vincitore agli Emmy John Mulaney, \"Big Mouth\"), e dal terrificante cacciatore di taglie, il Grande Lupo Cattivo (Wagner Moura, \"Narcos\").', 'https://mr.comingsoon.it/imgdb/locandine/big/59957.jpg'),
( 'Black Panther', 'La nazione del Wakanda si scontra con le potenze mondiali intervenute mentre piangono la perdita del loro re T\'Challa.', 'https://cdn1.thespacecinema.it/-/media/tsc/2022/11/black-panter-wakanda-forever/locandinatop.jpg?h=477&w=319'),
( 'Belle e Sebastien', 'A distanza di 4 anni dall\'ultimo capitolo, torna al cinema in una veste tutta nuova Belle & Sebastien, il grande classico che ha conquistato intere generazioni. Siamo ai giorni nostri e Sebastien, 10 anni, trascorre a malincuore le vacanze in montagna con la nonna e la zia, dando una mano nell\'ovile. Nulla di troppo entusiasmante per un ragazzo di citta` come lui. A rompere la monotonia delle sue giornate e` l\'incontro con Belle, un cane gigantesco e dolcissimo ma ingiustamente maltrattato dal suo padrone. Pronto a tutto pur di difendere e proteggere la sua nuova amica, Sebastien vivra` l\'estate piu` emozionante della sua vita.', 'https://notoriouspictures.it/wp-content/uploads/2022/09/BILLING-DATA.jpg'),
('Gli occhi del diavolo\r\n', 'In risposta all\'aumento globale delle possessioni demoniache, la Chiesa cattolica riapre le scuole di esorcismo per formare i sacerdoti al Rito dell\'Esorcismo. Su questo campo di battaglia spirituale sorge un\'improbabile guerriera: una giovane suora, Suor Ann (Jacqueline Byers). Sebbene alle suore sia vietato eseguire esorcismi, un professore (Colin Salmon) riconosce i doni di suor Ann e accetta di addestrarla. Spinta in prima linea spirituale con il compagno di studi Padre Dante (Christian Navarro), Suor Ann si ritrova in una battaglia per l\'anima di una giovane ragazza, che crede sia posseduta dallo stesso demone che ha tormentato sua madre anni fa. Presto si rende conto che il Diavolo vuole una sola anima: la sua.', 'https://resources5.eaglepictures.com/image/1/630/945/631077a9170bd/gli-occhi-del-diavolo-cover.jpeg'),
('Ipersonnia', 'Italia, futuro prossimo. Le vecchie carceri congestionate e violente sono solo un ricordo: ora i detenuti scontano la pena in uno stato di sonno profondo che li rende inoffensivi. L\'ipersonno è un sistema economico ed efficiente, perché ha drasticamente ridotto il tasso di recidiva criminale.', 'https://mr.comingsoon.it/imgdb/locandine/big/61664.jpg'),
('Napoli magica', 'Attraversare una città significa muoversi nello spazio, ma anche camminare a ritroso nel tempo. Un viaggio nel mito, nella leggenda, nei labirinti della città e nelle infinite storie che vi sono annidate. Da Virgilio Mago al fiume «fantasma», dalla leggenda nera di Raimondo di Sangro alla maledizione della Gaiola, dalla Sirena Partenope, demone marino o uccello antropomorfo, umanizzata al punto da morire per amore, ai misteri della città sotterranea, dal mito di Iside all\'enigmatica Y di Forcella, dai filosofi-maghi al diavolo della Pietrasanta, dalle Compagnie della Morte ai cori perduti delle fate, dai misteri archeologici ancora da svelare alle incredibili storie ambientate nei Castelli della città, si dipanano in queste pagine storie di sangue, di delitti e morte, di sesso e amanti insaziabili. Storie romantiche, cupe, feroci. Storie napoletane.', 'https://pad.mymovies.it/filmclub/2022/10/247/locandina.jpg');

INSERT IGNORE INTO `projections` (`ID_film`, `day`, `time`, `room`) VALUES 
('1', '2022-12-21', '11:37', '2'),
('2', '2022-12-22', '19:40', '9'),
('3', '2022-12-23', '20:23', '3'),
('4', '2022-12-24', '21:45', '4'),
('5', '2022-12-11', '11:51', '7'),
('6', '2022-12-14', '22:21', '6'),
('7', '2022-12-13', '00:32', '5'),
('8', '2022-12-15', '01:10', '7'),
('9', '2022-12-28', '19:01', '8'),
('10', '2022-12-29','18:45', '1');

");
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link href="style.css" rel="stylesheet">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="nav">
        <div class="logo"><img src="img/logo.png" class="logo2"></div>
        <div class="lgn"><button class="btn" onclick="Login()"><?php echo "".$_SESSION["lgn"].""   ?></button></div>
    </div>
    <div class="contenitore">
    <?php

        $query = $dbh->query("SELECT title,thumbnail,ID_film  FROM `films` 
        JOIN projections ON(projections.ID_film = films.ID)");
        
        $results = $query->fetchAll(PDO::FETCH_ASSOC);
        for($i = 0; $i < count($results); $i++){
            echo '<div class="contenitore2" value='.$results[$i]["ID_film"].'> <img class="image" src="'.$results[$i]["thumbnail"].'"> <br>
            <p class="title">'.$results[$i]["title"]. '</p></div>';
        }

    ?>
    <form name="films" action="film.php" method="POST">
        <input name="film" type="hidden" value="">
    </form>
    </div>
    <script src="js/index.js"></script>
</body>
</html>

















































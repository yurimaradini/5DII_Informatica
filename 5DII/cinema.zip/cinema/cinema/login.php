<?php
session_start();

if($_SESSION["lgn"] != "Login"){
  $_SESSION["lgn"] = "Login";
  header("Location: index.php");
}
else{}
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link rel="stylesheet" type="text/css" href="style.css" />
    <title>Static Template</title>
    <script src="https://cdn.tailwindcss.com"></script>
  </head>
  <body>
 
    <div id="contenitore">
    <div style="margin-top:23%" class="flex justify-center items-center flex-wrap h-full g-6 text-gray-800">
    <form id="form" name="formrg" method="POST" action="login2.php">

        <img id="logo" src="img/logo.png">
        <p class="font-serif text-2xl text-center font-bold text-sky-500 mb-5">Login with your account</p>

      <div class="mb-6">
        <input
          type="text"
          class="form-control block w-full px-4 py-2 text-xl font-normal bg-white text-gray-700  bg-clip-padding border border-solid border-gray-300 rounded transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none"
          placeholder="Name"
          id="mail"
          name="name"
        />
        
      </div>

      
      <div class="mb-6">
        <input
          type="password"
          class="form-control block w-full px-4 py-2 text-xl font-normal text-gray-700 bg-white bg-clip-padding border border-solid border-gray-300 rounded transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none"
          placeholder="Password"
          id="passwd"
          minlength="4"
          name="password"
        />
        <div class="flex justify-center items-center mt-5" id="loading">
          <svg role="status"
        class="inline h-8 w-8 animate-spin mr-2 text-gray-200 dark:text-gray-600 fill-gray-600 dark:fill-gray-300"
        viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path
          d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
          fill="currentColor" />
        <path
          d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
          fill="currentFill" />
      </svg>
      <p class="text-white font-medium text-sm uppercase">Loading</p>
    </div>
      </div>

    </form>
      <button
      
        id="bottone_login"
        class=" inline-block px-7 py-3 bg-blue-600 text-white font-medium text-sm uppercase rounded shadow-md hover:bg-blue-700 hover:shadow-lg focus:bg-blue-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg w-7/12"
        data-mdb-ripple="true"
        data-mdb-ripple-color="light"
      >
        Sign in
      </button>
      
    <br>
  <div class="register"><a style="color: violet; text-decoration-line: underline;" href="register.php">Register here</a></div>
  </div>
</div>

</div>

</div>

</div>
<script>
    document.getElementById("logo").addEventListener("click", () =>{
        window.location = "index.php";
    })

    document.getElementById("logo").addEventListener("mouseover", () =>{
        document.getElementById("logo").style.cursor = "pointer";
    })

    document.getElementById("bottone_login").addEventListener("click", () =>{
  document.formrg.submit();
})




</script>

  </body>
</html>

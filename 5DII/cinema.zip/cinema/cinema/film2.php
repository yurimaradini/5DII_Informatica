<?php
session_start();
print_r($_POST["film"]);
$_SESSION["ID_proiezione"] = $_POST["film"];
if($_SESSION["lgn"] == "Login"){
    header("Location: login.php");
}

require_once "dbconfig.php";

$query = $dbh->query("SELECT * FROM `films` 
                    JOIN projections ON(projections.ID_film = films.ID) 
                    WHERE projections.ID = " .$_POST["film"]);
        
$results = $query->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link href="style.css" rel="stylesheet">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="nav">
        <div id="lg" class="logo"><img src="img/logo.png" class="logo2"></div>
        <div class="lgn"><button class="btn" onclick="Login()"><?php echo "".$_SESSION["lgn"].""   ?></button></div>
    </div>
    <div class="cntposti">
        <form method="POST" action="film3.php" style="display: flex; flex-direction: row; flex-wrap: wrap; justify-content: center;">
        <?php       
            
            $querys = $dbh->prepare("SELECT * FROM `bookings` WHERE ID_projection = :id;");
            
            $querys->bindParam(":id",$_SESSION["ID_proiezione"], PDO::PARAM_STR);
            $querys->execute();
            $results = $querys->fetchAll(PDO::FETCH_ASSOC);
            if(empty($results)){
                $_SESSION["numposto"] = 0; 
            }
            else{
                $_SESSION["numposto"] = $results; 
            }
            $control = false;
            for($i = 0; $i < 30; $i++){
                    if($_SESSION["numposto"] != 0){
                        for($s = 0; $s < count($_SESSION["numposto"]); $s++){

                            if($i == $_SESSION["numposto"][$s]["sit_number"]){
                                echo '<input class="posto_occupato">  ';
                                $control = true;
                                }
                        }
                    }
                if($control == true){

                }
                else{
                    echo '<input type="submit" class="posto" name="pst" value="'.$i.'">';         
                }
                $control = false;  
            }
         
        ?>
        </form>
    </div> 
    <script>
        document.getElementById("lg").addEventListener("click", () =>{
        window.location = "index.php";
    })
    </script>
    <script src="js/index.js"></script>
</body>
</html>
<?php
session_start();

$dbh = new PDO("mysql:host=localhost", "root", "");
require_once "dbconfig.php";

$query = "INSERT INTO `users` (`ID`, `name`, `email`, `password`) 
                    VALUES (NULL, :na, :em, :pw);";
        
$s = $dbh->prepare($query);

$s->bindParam(":na",$_POST["name"], PDO::PARAM_STR);
$s->bindParam(":em",$_POST["mail"], PDO::PARAM_STR);
$s->bindParam(":pw",$_POST["password"], PDO::PARAM_STR);

$s->execute();

header("Location: index.php");
?>
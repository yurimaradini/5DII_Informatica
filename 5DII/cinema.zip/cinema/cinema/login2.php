<?php
session_start();

$dbh = new PDO("mysql:host=localhost", "root", "");
require_once "dbconfig.php";
$query = $dbh->prepare("SELECT * FROM `users` WHERE `name` LIKE :em AND `password` LIKE :pw ;");

$query->bindParam(":em",$_POST["name"], PDO::PARAM_STR);
$query->bindParam(":pw",$_POST["password"], PDO::PARAM_STR);

$query->execute();
$results = $query->fetch(PDO::FETCH_OBJ);

if(empty($results)){
    header("Location: login.php");
}
else{
    $_SESSION["lgn"] = $_POST["name"];
    $_SESSION["ID_user"] = $results->ID; 
    header("Location: index.php");
    
}


?>
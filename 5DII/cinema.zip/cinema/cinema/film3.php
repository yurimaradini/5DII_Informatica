<?php
session_start();
//print_r($_SESSION["ID_user"]);
//print_r($_SESSION["ID_proiezione"]);
//print_r($_POST["pst"]);


$dbh = new PDO("mysql:host=localhost", "root", "");
require_once "dbconfig.php";

$_code = rand(12345678, 876543231);
$query = $dbh->exec("INSERT IGNORE INTO `bookings`(`code`, `ID_projection`, `ID_user`, `sit_number`) 
    VALUES ('".$_code. "','".$_SESSION["ID_proiezione"]."','".$_SESSION["ID_user"]."','".$_POST["pst"]."')");
header("Location: index.php");

?>
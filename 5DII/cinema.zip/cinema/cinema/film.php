<?php
session_start();

$dbh = new PDO("mysql:host=localhost", "root", "");
require_once "dbconfig.php";
$query = $dbh->query("SELECT * FROM `films` 
                    JOIN projections ON(projections.ID_film = films.ID) 
                    WHERE films.ID ="  .$_POST["film"]. ";");
        
$results = $query->fetchAll(PDO::FETCH_ASSOC);
$_SESSION["ID_film"] =  $results[0]["ID"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link href="style.css" rel="stylesheet">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="nav">
        <div id="lg" class="logo"><img src="img/logo.png" class="logo2"></div>
        <div class="lgn"><button class="btn" onclick="Login()"><?php echo "".$_SESSION["lgn"].""   ?></button></div>
    </div>
    <div class="cnt">
        <?php  echo "<img class='img' src='". $results[0]["thumbnail"] ."'>"?>
        <div style="height: 1000px; float: left; width: 38px;"></div>
        <p class="title2"><?php  echo "". strtoupper($results[0]["title"]) .""?></p><br><br>
        <p class="plot"><?php  echo "". $results[0]["plot"] .""?></p><br><br><br><br>
        <div id="or" class="ora" value=<?php  echo "". $results[0]["ID"] .""?>>
            <p class="ora2" style="margin-left: 21px;"><?php  echo "Time: ". substr($results[0]["time"],0,5) .""?></p>
            <p class="ora2"><?php  echo "Room: ". $results[0]["room"] .""?></p>
        </div>
    </div>
    <form name="films" action="film2.php" method="POST">
        <input name="film" type="hidden" value="" required>
    </form>


    <script>
    document.getElementById("lg").addEventListener("click", () =>{
        window.location = "index.php";
    })

    document.getElementById("lg").addEventListener("mouseover", () =>{
        document.getElementById("lg").style.cursor = "pointer";
    })

    document.getElementById("or").addEventListener("click", (e) =>{
    
    document.films.film.value = e.target.parentElement.getAttribute('value');
    document.films.submit();
    })  
</script>
<script src="js/index.js"></script>
</body>
</html>
<?php 

function getName($str) {
    $nameV = ""; //vowels in the name
    $nameC = ""; //consonants in the name
    
    $vowels = "AEIOU";

    for ($i = 0; $i < min(6, strlen($str)); $i++) {
        if (strpos($vowels, $str[$i]) !== false) {
            $nameV .= $str[$i];
        }
        else {
            $nameC .= $str[$i];
        }
    }

    $res = "";
    $i = 0;
    $j = 0;
    while (strlen($res) < 3) {
        if ($i < strlen($nameC)) {
            $res .= $nameC[$i];       
            $i++;
        }
        else if ($j < strlen($nameV)){
            $res .= $nameV[$j];
            $j++;
        }
        else {
            $res .= 'X';
        }
    }

    return $res;
}

function getYearMonthDay($date, $gender) {
    $res = "";

    $dateArr = explode('-', $date);

    $res .= substr($dateArr[0], -2); //get year

    $monthCode = [
        '01' => 'A',
        '02' => 'B',
        '03' => 'C',
        '04' => 'D',
        '05' => 'E',
        '06' => 'H',
        '07' => 'L',
        '08' => 'M',
        '09' => 'P',
        '10' => 'R',
        '11' => 'S',
        '12' => 'T'
    ];

    $res .= $monthCode[substr($dateArr[1], 0)]; //get month code
    
    $day = substr($dateArr[2], 0);

    if ($gender == 'f') {
        $dayInt = (int)$day + 40;
        $day = (string)$dayInt;
    }

    $res .= $day; //get day

    return $res;
}

function getTown($town) {
    $people_json = file_get_contents('comuni.json');
 
    $decoded_json = json_decode($people_json, true);

    //TODO : read json file
    return null;
}

echo getName(strtoupper($_POST['surname']));
echo getName(strtoupper($_POST['name']));
echo getYearMonthDay($_POST['date'], $_POST['gender']);
echo getTown($_POST['town']);
?>
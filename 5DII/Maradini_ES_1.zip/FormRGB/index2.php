<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php 
    $red = $_GET["red"];
    $green = $_GET["green"];
    $blue = $_GET["blue"];

    echo '<style type="text/css">
    body {
        background-color: rgb(' . $red .','.$green .','.$blue .');
        text-align: center;
    }
    h1 {
        color: white;
    }
    </style>'; 
?>
<h1>#<?php echo dechex($red) . dechex($green) . dechex($blue);?></h1>
</body>

</html>
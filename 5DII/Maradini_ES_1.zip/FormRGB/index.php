<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="GET" action="index2.php">
        <label for="red">Red</label>
        <input id="red" name="red" type="number" min="0" max="255">
        <br>
        <label for="green">Green</label>
        <input id="green" name="green" type="number" min="0" max="255">
        <br>
        <label for="blue">Blue</label>
        <input id="blue" name="blue" type="number" min="0" max="255">
        <br>
        <input type="submit">
    </form>
</body>
</html>
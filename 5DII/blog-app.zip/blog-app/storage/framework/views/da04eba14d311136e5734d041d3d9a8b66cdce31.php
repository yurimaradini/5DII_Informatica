<div class="nav-scroller py-1 mb-2">
    <nav class="nav d-flex justify-content-around">
    	<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      	<a class="p-2 link-secondary" href="<?php echo e(route('category', $c->id)); ?>"><?php echo e($c->title); ?></a>
    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </nav>
  </div><?php /**PATH C:\xampp\htdocs\5DII\blog-app\resources\views/partials/categories.blade.php ENDPATH**/ ?>